<?php

include 'ConnectionDatabase.php';

header('Content-Type: text/plain; charset=utf-8');

$id=$_POST['id'];

try {

    /**
    if (!$name || !$location || !$operator || !$commission || !$description || !$power || !$production || !$co2 || !$reimbursement)
        throw new RuntimeException('You should fill all the required fields');

    // Undefined | Multiple Files | $_FILES Corruption Attack
    // If this request falls under any of them, treat it invalid.
    if (
        !isset($_FILES['photo']['error']) ||
        is_array($_FILES['photo']['error'])
    ) {
        throw new RuntimeException('Invalid photo parameters.');
    }

    // You should also check filesize here.
    if ($_FILES['photo']['size'] == 0) {
        $photo = ""; // then no file was sent
    } else {

        // Check MIME Type by yourself.
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        if (false === $ext = array_search(
                $finfo->file($_FILES['photo']['tmp_name']),
                array(
                    'jpg' => 'image/jpeg',
                    'png' => 'image/png',
                    'gif' => 'image/gif',
                ),
                true
            )) {
            throw new RuntimeException('Invalid photo format.');
        }
    }

    echo 'Your PV is uploaded successfully.';
*/
    // Delete - General table
    $query = $connection->prepare("DELETE FROM general WHERE id=$id"); // querying the database
    $query->execute();

    // Delete - efficiency table
    $query = $connection->prepare("DELETE FROM efficiency WHERE id=$id"); // querying the database
    $query->execute();

    // Delete - hardware table
    $query = $connection->prepare("DELETE FROM hardware WHERE id=$id"); // querying the database
    $query->execute();

    echo 1;

} catch (RuntimeException $e) {

    echo $e->getMessage();

}